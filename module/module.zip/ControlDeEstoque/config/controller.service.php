<?php
return array(
    'ControlDeEstoque\\Controller\\ControleEstoque' => '\\ControlDeEstoque\\Controller\\Factory\\FactoryController',
    'ControlDeEstoque\\Controller\\Marca' => '\\ControlDeEstoque\\Controller\\Factory\\FactoryController',
    'ControlDeEstoque\\Controller\\Produto' => '\\ControlDeEstoque\\Controller\\Factory\\FactoryController',
    'ControlDeEstoque\\Controller\\Categoria' => '\\ControlDeEstoque\\Controller\\Factory\\FactoryController',
    'ControlDeEstoque\\Controller\\Tag' => '\\ControlDeEstoque\\Controller\\Factory\\FactoryController',
    'ControlDeEstoque\\Controller\\ProdutCatBrandTag' => '\\ControlDeEstoque\\Controller\\Factory\\FactoryController',
);
