<?php
return array(
    'SIGAUpload\\Controller\\Upload' => '\\SIGAUpload\\Controller\\Factory\\FactoryController',
    'SIGAUpload\\Controller\\Galeria' => '\\SIGAUpload\\Controller\\Factory\\FactoryController',
);
