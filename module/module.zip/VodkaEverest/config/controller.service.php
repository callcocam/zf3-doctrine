<?php
return array(
    "VodkaEverest\Controller\Start" => '\\VodkaEverest\\Controller\\Factory\\FactoryController',
);
