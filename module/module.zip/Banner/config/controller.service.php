<?php
return array(
    'Banner\\Controller\\Banner' => '\\Banner\\Controller\\Factory\\FactoryController',
);
