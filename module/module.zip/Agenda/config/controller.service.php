<?php
return array(
    'Agenda\\Controller\\Categorie' => '\\Agenda\\Controller\\Factory\\FactoryController',
    'Agenda\\Controller\\Evento' => '\\Agenda\\Controller\\Factory\\FactoryController',
);
