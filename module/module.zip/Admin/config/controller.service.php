<?php
return array(
    'Admin\\Controller\\Admin' => '\\Admin\\Controller\\Factory\\FactoryController',
    'Admin\\Controller\\Menu' => '\\Admin\\Controller\\Factory\\FactoryController',
    'Admin\\Controller\\Empresa' => '\\Admin\\Controller\\Factory\\FactoryController',
    'Admin\\Controller\\Role' => '\\Admin\\Controller\\Factory\\FactoryController',
    'Admin\\Controller\\Resource' => '\\Admin\\Controller\\Factory\\FactoryController',
    'Admin\\Controller\\User' => '\\Admin\\Controller\\Factory\\FactoryController',
    'Admin\\Controller\\Config' => '\\Admin\\Controller\\Factory\\FactoryController',
    'Admin\\Controller\\Client' => '\\Admin\\Controller\\Factory\\FactoryController',
    'Admin\\Controller\\Privilege' => '\\Admin\\Controller\\Factory\\FactoryController',
    'Admin\\Controller\\Group' => '\\Admin\\Controller\\Factory\\FactoryController',
);
