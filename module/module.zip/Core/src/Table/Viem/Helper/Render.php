<?php
/**
 * Created by PhpStorm.
 * User: caltj
 * Date: 27/03/2018
 * Time: 20:10
 */

namespace Core\Table\View\Helper;


use Zend\View\Helper\AbstractHelper;

class Render extends AbstractHelper
{

}