<?php
/**
 * Created by PhpStorm.
 * User: caltj
 * Date: 17/03/2018
 * Time: 15:50
 */

namespace Core\Entity;


use Doctrine\ORM\EntityRepository;

class AbstractRepository extends EntityRepository
{

}