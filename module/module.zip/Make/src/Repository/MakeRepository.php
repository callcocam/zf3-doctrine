<?php
/**
 * Created by PhpStorm.
 * User: caltj
 * Date: 18/03/2018
 * Time: 01:33
 */

namespace Make\Repository;


use Core\Entity\AbstractRepository;

class MakeRepository extends AbstractRepository
{

}