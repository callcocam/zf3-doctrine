<?php
/**
 * Created by PhpStorm.
 * User: caltj
 * Date: 27/03/2018
 * Time: 20:02
 */

namespace Core\Listar;


class AbstractTable
{



}