<?php
return array(
    'Blog\\Controller\\Blog' => '\\Blog\\Controller\\Factory\\FactoryController',
    'Blog\\Controller\\Post' => '\\Blog\\Controller\\Factory\\FactoryController',
    'Blog\\Controller\\CategorieBlog' => '\\Blog\\Controller\\Factory\\FactoryController',
);
