<?php

namespace Core\Dotenv\Exception;

/**
 * This is the exception interface.
 */
interface ExceptionInterface
{
    //
}
